Measuring the Pulse of Prosperity:An Index of Economic Freedom Analysis

Project Description
This project analyzes economic freedom indicators using Tableau visualizations and web integration.

 Technologies Used
- Tableau Public
- HTML
- CSS
- GitHub Pages

## Live Website
https://yuvasreekanjibedu.github.io/Measuring-the-Pulse-of-Prosperity-An-Index-of-Economic-Freedom-Analysis/
